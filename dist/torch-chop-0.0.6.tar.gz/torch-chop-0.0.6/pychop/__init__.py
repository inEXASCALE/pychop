from .chop import chop
from .simulate import simulate

__version__ = '0.0.6'  
__backend__ = 'NumPy'  